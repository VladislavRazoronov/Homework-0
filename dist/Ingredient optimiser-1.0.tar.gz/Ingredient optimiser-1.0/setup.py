from distutils.core import setup
import pydoc
setup(
    name='Ingredient optimiser',
    version='1.0',
    package_dir={'':'work'},
    packages=[''],
    author='Vladislav razoronov',
    author_email='razoronov@ucu.edu.ua',
    url='https://github.com/VladislavRazoronov/Ingredient-optimiser',
    description='A program for analyzing recipes'
    )
